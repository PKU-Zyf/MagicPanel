# MagicPanel

MagicPanel库为面板数据集的优化与合并提供了便利。

点击[此处](https://github.com/PKU-Zyf/MagicPanel/raw/main/MagicPanel.pdf)下载MagicPanel最新版本的用户手册。

点击[此处](https://github.com/PKU-Zyf/MagicPanel)前往MagicPanel的GitHub主页，查看更新日志、示例代码等资源。
